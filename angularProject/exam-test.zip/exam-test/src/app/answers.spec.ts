import { Answers } from './answers';

describe('Answers', () => {
  it('should create an instance', () => {
    expect(new Answers()).toBeTruthy();
  });
});
