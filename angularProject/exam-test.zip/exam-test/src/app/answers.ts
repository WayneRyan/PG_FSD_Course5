export class Answers {
  constructor(public qnumber:number, public answer:string) {
  }
}
